print("KhinSandarYu has three idol types: agustd, minyoongi, and suga")
